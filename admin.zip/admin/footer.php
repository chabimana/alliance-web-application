
<div>
    <script src="../view/static/js/jquery.min.js"></script>
    <script src="../view/static/js/bootstrap.min.js"></script>
    <script src="../view/static/js/jquery.dataTables.min.js"></script>
    <script src="../view/static/js/dataTables.bootstrap.min.js"></script>
    <script src="../view/static/js/adminlte.min.js"></script>
</div>
</body>
</html>