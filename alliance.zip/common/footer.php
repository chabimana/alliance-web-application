
<footer class="main-footer">
			<div class="container">
				<div class="pull-right hidden-xs">
					<b>Version</b> 1.0
				</div>
				<strong>Copyright &copy; 2018-2019 <a href="#">www.alliance.com</a>.
				</strong> All rights reserved.
			</div>
			<!-- /.container -->
		</footer>
		<div class="control-sidebar-bg"></div>
	</div>
	<div>
		<script src="view/static/old/js/jquery.min.js"></script>
		<script src="view/static/old/js/bootstrap.min.js"></script>
		<script src="view/static/old/js/jquery.dataTables.min.js"></script>
		<script src="view/static/old/js/dataTables.bootstrap.min.js"></script>
		<script src="view/static/old/js/adminlte.min.js"></script>
	</div>
</body>
</html>